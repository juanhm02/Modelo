n=int(input("numero"))
i = 2
while i<=n:
  if(n/i) == (n//i):
    break
  i += 1
print(i)  